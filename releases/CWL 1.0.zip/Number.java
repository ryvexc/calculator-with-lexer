public class Number {
    private double value;

    public Number(double value) { this.value = value; }
    public String __repr__() { return String.valueOf(this.value); }
}
